function mytest(){
    alert("외부 파일에서 실행됨!");
}

// window.onload
onload=function(){
    alert("window가 로딩됨!");
}
